from setuptools import setup, find_packages

setup(
    name='regex_enumerator',
    version='0.1',
    packages=find_packages(include=['regex_enumerator']),
    description='Enumerate all strings that match a given regex',
    author='Vincenzo Greco',
    setup_requires=['pytest-runner'],
    tests_require=['pytest'],
    test_suite='tests',
)