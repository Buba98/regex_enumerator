from regex_parser import RegexParser
from regex_tree import RegexTree

class RegexEnumerator:
    def __init__(self, regex: str):
        self.regex: str = regex
        self.regexTree: RegexTree = RegexParser().parse(regex)

    def next(self) -> str:
        return self.regexTree.next()
