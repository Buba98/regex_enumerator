class CharClasses:
    def __init__(self, chars_list: list[str], min_len: int, max_len: int):
        self.index = 0
        self.chars: str = ''.join(sorted(set(''.join(chars_list))))
        self.min_len = min_len
        self.max_len = max_len

    def current(self) -> str:
        if len(self.chars) == 0 or self.max_len == 0:
            return ''

        base = len(self.chars)
        if base == 1:
            if self.max_len is not None and self.index >= self.max_len:
                self.index = 0
            return self.chars[0] * (self.min_len + self.index)

        res = []
        if self.max_len is not None and base ** self.min_len + self.index >= base ** (self.max_len + 1):
            self.index = 0

        num = base ** self.min_len + self.index

        while num > 1:
            res.append(self.chars[num % base])
            num //= base

        return ''.join(reversed(res))

    def next(self) -> str:
        res = self.current()
        self.index += 1
        return res


class Alternative:
    def __init__(self, charClassesList: list[CharClasses]):
        self.index = 0
        self.charClassesList: list[CharClasses] = charClassesList

    def next(self) -> str:
        res = ''
        for i in range(len(self.charClassesList)):
            if i == self.index % len(self.charClassesList):
                res += self.charClassesList[i].next()
            else:
                res += self.charClassesList[i].current()

        self.index += 1
        return res


class RegexTree:
    def __init__(self):
        self.alternatives: list[Alternative] = []
        self.index = 0

    def addAlternative(self, alternative: Alternative):
        self.alternatives.append(alternative)

    def next(self) -> str:
        res = self.alternatives[self.index % len(self.alternatives)].next()
        self.index += 1
        return res
