from regex_enumerator import RegexEnumerator

def test_regex_enumerator():
    regexEnumerator = RegexEnumerator('[ab]{2}')
    assert regexEnumerator.next() == 'aa'
    assert regexEnumerator.next() == 'ab'
    assert regexEnumerator.next() == 'ba'
    assert regexEnumerator.next() == 'bb'
    assert regexEnumerator.next() == 'aa'